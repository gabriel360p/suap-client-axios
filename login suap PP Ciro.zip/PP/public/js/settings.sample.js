var CLIENT_ID = '';
var HOME_URI = 'http://localhost:8000';
var REDIRECT_URI = HOME_URI + '/dashboard';
var SUAP_URL = 'https://suap.ifrn.edu.br';
var SCOPE = 'identificacao email documentos_pessoais';
