var CLIENT_ID = 'EtPS64uudgfI9faF0K3LTiw1h9h8Smu64uIDwRV7';
var HOME_URI = 'http://localhost:8000';
var REDIRECT_URI = HOME_URI + '/authorization-view';
var SUAP_URL = 'https://suap.ifrn.edu.br';
var SCOPE = 'identificacao email documentos_pessoais';
