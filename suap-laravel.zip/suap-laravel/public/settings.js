var CLIENT_ID = '0y6KfWBgwN2S1ViJCLcVSxuaIKaSjg50ALfMru5D';
var REDIRECT_URI = 'http://localhost:8000/';
var SUAP_URL = 'https://suap.ifrn.edu.br';
var SCOPE = 'identificacao email documentos_pessoais';